Directory contains files:

Datasets:
- chat_gpt-binary.csv - data with labels generated using Chat Gpt,
- expert-1-3-groups.csv  - data with 4 labels determined by expert,
- expert-1-binary.csv - data with 2 (true, false) labels determined by expert,
dataset_threats_social_media.csv - files containing all above.

Scripts:
- Posts_ML_Example.ipynb - Jupyter file with example of ML process for expert-1-binary dataset. 
